
This library allows you to display simple Rich Text Format (RTF) files in
SDL applications.

The RTF format specification is available at:
http://msdn.microsoft.com/library/default.asp?url=/library/en-us/dnrtfspec/html/rtfspec.asp

The showrtf example application relies on the SDL_ttf library for loading
fonts and displaying text.
The SDL_ttf library can be found at: http://www.libsdl.org/projects/SDL_rtf/

To make the library, type './configure' then 'make' to build the SDL rtf
library and the showrtf example application.

This library is under the zlib license, see the file "LICENSE.txt" for details.

Enjoy!
	-Sam Lantinga <slouken@libsdl.org>		(8/16/2003)
